TotalScore = 0
Word = "Why isnt this working"
HighScore = 0
I = True
import time
import multiprocessing
def MainMenu():
  i = True
  while i == True:
    print("1: Check Word Value")
    print("2: Play Timed Round")
    print("3: Check High Score")
    print("4: Exit")
    u = input("Option Select: ")
    if u == "1":
      EvaluateScore()
    elif u == "2":
      p = multiprocessing.Process(target=TimedRound, name="Timed")
      p.start() 
      time.sleep(60)
      p.terminate()
      p.join()
    elif u == "3":
      CheckHighScore()
    elif u == "4":
      i = False
def Timer():
  i = 0
  global I
  while i < 60:
    time.sleep(1)
    i+=1
  print("60 seconds have passed")
  I = False
def TimedRound():
  global TotalScore 
  global HighScore
  global I
  TotalScore = 0
  I = True
  while I == True:
    EvaluateScore()
    if TotalScore > HighScore:
      HighScore = TotalScore

def EvaluateScore():
  i=0
  y=0
  global TotalScore
  global Word
  Word = input("Select a word: ")
  Word = Word.lower()
  while i < len(Word):
    x = Word[i:i+1]
    if x == "e":
      y+=1
    elif x == "a":
      y+=1
    elif x == "r":
      y+=2
    elif x == "i":
      y+=2
    elif x == "o":
      y+=2
    elif x == "t":
      y+=2
    elif x == "n":
      y+=2
    elif x == "s":
      y+=2
    elif x == "l":
      y+=2
    elif x == "c":
      y+=2
    elif x == "u":
      y+=3
    elif x == "d":
      y+=3
    elif x == "p":
      y+=4
    elif x == "m":
      y+=4
    elif x == "h":
      y+=4
    elif x == "g":
      y+=5
    elif x == "b":
      y+=5
    elif x == "f":
      y+=6
    elif x == "y":
      y+=6
    elif x == "w":
      y+=9
    elif x == "k":
      y+=10
    elif x == "v":
      y+=11
    elif x == "x":
      y+=38
    elif x == "z":
      y+=41
    elif x == "j":
      y+=57
    elif x == "q":
      y+=57
    i+=1
  print(f"The word is worth {y} points")
  TotalScore+=y
  print(TotalScore)

  return y

MainMenu()